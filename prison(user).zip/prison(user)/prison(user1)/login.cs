﻿using prison_user2_;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prison_user1_
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }
        Employeerepo emprepo = new Employeerepo();

        private void button1_Click(object sender, EventArgs e)
        {
            Employee a = new Employee();
            a.Employeename = textBox1.Text;
            a.Password = textBox2.Text;

            if (emprepo.userloginvalidation(a))
            {
                home f2 = new home();
                this.Hide();
                f2.Show();
            }
            else
            {
                MessageBox.Show("Invalid Id or Password", "Login Failed");
            }
        }
    }
}
