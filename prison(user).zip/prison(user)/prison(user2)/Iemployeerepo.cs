﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prison_user2_
{
    interface Iemployeerepo
    {
        bool Insert(Employee b);
        bool Update(Employee b);
        bool Delete(string Employeeid);
        Employee GetEmployee(string Employeeid);
        List<Employee> GetAllEmployee();
        bool userloginvalidation(Employee emp);
    }
}
