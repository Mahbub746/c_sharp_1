﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prison_user2_
{
    public class Database
    {
           
        
        private SqlConnection myconnection;
        private SqlCommand mycommand;

        public Database()
        {
            string connectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=E:\PRISON\prison(user)\user.mdf;Integrated Security=True;Connect Timeout=30";
            myconnection = new SqlConnection(connectionString);
        }
        public void ConnectWithDB()
        {
            myconnection.Open();
        }
        public void CloseConnection()
        {
            myconnection.Close();
        }
        public SqlDataReader GetData(string query)
        {
            mycommand = new SqlCommand(query, myconnection);
            return mycommand.ExecuteReader();
            
        }
        public int ExecuteSQL(string query)
        {
            mycommand = new SqlCommand(query, myconnection);
            return mycommand.ExecuteNonQuery();
            

        }
    }
}
